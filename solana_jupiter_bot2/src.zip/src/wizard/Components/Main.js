import React from "react.js";
import { Box } from "ink.js";
import WizardContext from "../WizardContext.js";
import { useContext } from "react.js";
import importJsx from "import-jsx.js";
import Divider from "ink-divider.js";
const Router = importJsx("./Router");

function Main() {
	const { nav } = useContext(WizardContext);
	return (
		<Box flexDirection="column">
			<Divider title={nav.steps[nav.currentStep]} />
			<Box marginY={1}>
				<Router />
			</Box>
		</Box>
	);
}
export default Main;
