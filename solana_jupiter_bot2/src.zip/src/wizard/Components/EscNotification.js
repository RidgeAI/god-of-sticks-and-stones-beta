import React from "react.js";
import { Box, Text } from "ink.js";

const EscNotification = () => {
	return (
		<Box paddingTop={1}>
			<Text dimColor color="yellow">
				Use <Text bold>ESC</Text> key if U wanna exit
			</Text>
		</Box>
	);
};

export default EscNotification;
