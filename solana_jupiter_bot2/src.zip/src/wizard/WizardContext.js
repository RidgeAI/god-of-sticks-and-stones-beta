import { createContext } from "react.js";
import { initialState } from "./reducer.js";

const WizardContext = createContext(initialState);

export default WizardContext;
