import React from "react.js";
import { Box, Text } from "ink.js";
import { useContext, useState, useRef, useEffect } from "react.js";
import WizardContext from "../WizardContext.js";
import { default: TextInput } from "ink-text-input.js";
import chalk from "chalk.js";
import { default: SelectInput } from "ink-select-input.js";

const TRADING_SIZE_STRATEGIES = [
	{ label: "cumulative", value: "cumulative" },
	{ label: "fixed", value: "fixed" },
];

const Indicator = ({ label, value }) => {
	const {
		config: {
			"trading size": { value: selectedValue },
		},
	} = useContext(WizardContext);

	const isSelected = value === selectedValue.strategy;

	return <Text>{chalk[isSelected ? "greenBright" : "white"](`${label}`)}</Text>;
};

function TradingSize() {
	let isMountedRef = useRef(false);

	const {
		config: {
			tokens: { value: tokensValue },
			"trading size": { value: tradingSizeValue },
		},
		configSetValue,
	} = useContext(WizardContext);

	const [tradingSize, setTradingSize] = useState(tradingSizeValue.value);
	const [inputBorderColor, setInputBorderColor] = useState("gray");

	const handleTradingSizeStrategySelect = (selected) => {
		configSetValue("trading size", {
			value: {
				strategy: selected.value,
				value: tradingSize,
			},
		});
	};

	const handleTradingSizeChange = (value) => {
		if (!isMountedRef.current) return;

		const badChars = /[^0-9.]/g;
		badChars.test(value)
			? setInputBorderColor("red")
			: setInputBorderColor("gray");
		const sanitizedValue = value.replace(badChars, "");
		setTimeout(() => isMountedRef.current && setInputBorderColor("gray"), 100);
		setTradingSize(sanitizedValue);
	};

	useEffect(() => {
		isMountedRef.current = true;
		return () => (isMountedRef.current = false);
	}, []);

	return (
		<Box flexDirection="column">
			<Text>
				Set <Text color="#cdadff">trading size</Text> strategy:
			</Text>
			<Box margin={1}>
				<SelectInput
					items={TRADING_SIZE_STRATEGIES}
					onSelect={handleTradingSizeStrategySelect}
					itemComponent={Indicator}
				/>
			</Box>
			<Box flexDirection="row" alignItems="center">
				<Text>Trading Size:</Text>
				<Box borderStyle="round" borderColor={inputBorderColor} marginLeft={1}>
					<TextInput
						value={tradingSize || ""}
						placeholder="0.0"
						onChange={handleTradingSizeChange}
						// onSubmit={(value) => handleSubmit("percent", value)}
					/>
					<Text color="gray"> {tokensValue.tokenA.symbol}</Text>
				</Box>
			</Box>
		</Box>
	);
}
export default TradingSize;
