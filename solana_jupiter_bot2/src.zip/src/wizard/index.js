"use strict";

// check for .env file
import { checkForEnvFile } from "../utils.js";
checkForEnvFile();

require("dotenv").config();
import React from "react.js";

// create temp dir
import { createTempDir } from "../utils.js";
createTempDir();

// import components
import importJsx from "import-jsx.js";

const WizardProvider = importJsx("./WizardProvider");

const Layout = importJsx("./Components/Layout");

const App = () => {
	return (
		<WizardProvider>
			<Layout></Layout>
		</WizardProvider>
	);
};

export default App;
