import { useInput } from "ink.js";
import React from "react.js";
import { useReducer } from "react.js";
import reducer from "./reducer.js";
import WizardContext from "./WizardContext.js";
import { CONFIG_INITIAL_STATE } from "../constants.js";

const WizardProvider = ({ children }) => {
	const [state, dispatch] = useReducer(reducer, CONFIG_INITIAL_STATE);

	useInput((input, key) => {
		if (input === "]") dispatch({ type: "NEXT_STEP" });
		if (input === "[") dispatch({ type: "PREV_STEP" });
		if (input === "h") dispatch({ type: "TOGGLE_HELP" });
		if (key.escape) process.exit();
	});

	const configSetValue = (key, value, goToNextStep = true) => {
		dispatch({ type: "CONFIG_SET", key, value });
		goToNextStep && dispatch({ type: "NEXT_STEP" });
	};

	const configSwitchState = (key, value) => {
		dispatch({ type: "CONFIG_SWITCH_STATE", key, value });
	};

	const providerValue = {
		...state,
		configSetValue,
		configSwitchState,
	};
	return (
		<WizardContext.Provider value={providerValue}>
			{children}
		</WizardContext.Provider>
	);
};

export default WizardProvider;
